import "./Footer.css";

const Footer = () => (
  <footer className="footer">
    <div>Developed by Practicum Students</div>
    <div>2023</div>
  </footer>
);

export default Footer;
